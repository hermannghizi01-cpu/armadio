# Guardaroba – come ottenere l'APK

Non serve installare nulla sul computer. GitHub costruisce l'APK per te.

1. Crea un account gratuito su github.com (se non ce l'hai).
2. Crea un nuovo repository (pulsante "New"), chiamalo "guardaroba".
3. Carica TUTTO il contenuto di questa cartella (compresa la cartella nascosta ".github"):
   "Add file" > "Upload files". Se ".github" non si carica dal browser, crea il file
   a mano: "Add file" > "Create new file", nome ".github/workflows/build-apk.yml",
   e incolla il contenuto del file con lo stesso nome.
4. Vai nella scheda "Actions". Se chiede di abilitare i workflow, accetta.
5. Scegli "Crea APK" > "Run workflow". Attendi 5-10 minuti.
6. Apri l'esecuzione completata e scarica "guardaroba-apk" in fondo alla pagina (è uno zip con app-debug.apk).
7. Copia app-debug.apk sul telefono Android e aprilo. Se richiesto, consenti
   "Installa app da fonti sconosciute" per il browser o il file manager.

Note
- L'APK è "debug": si installa normalmente ma non è pubblicabile sul Play Store.
- L'analisi dei colori con il selfie e il riconoscimento AI dei capi funzionano solo nella versione dentro Claude.
  Nell'APK restano disponibili questionario, armadio, outfit, avatar, preferiti e download palette.
- I dati restano sul telefono (memoria dell'app).
- Per iPhone non esiste l'APK: apri il link della pagina e usa "Aggiungi a schermata Home".
